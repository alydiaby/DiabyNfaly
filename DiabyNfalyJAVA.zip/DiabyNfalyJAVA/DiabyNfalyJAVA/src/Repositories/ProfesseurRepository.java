package Repositories;

public class ProfesseurRepository {
    
}
