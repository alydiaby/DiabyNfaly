package Repositories;

public class ModuleRepository {
    
}
