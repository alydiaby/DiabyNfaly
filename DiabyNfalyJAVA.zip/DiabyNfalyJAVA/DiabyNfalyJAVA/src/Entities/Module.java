package Entities;




public class Module {

    private int idMod;
    private String nomModule;

    
    public Module() {
    }
    
    public int getIdMod() {
        return idMod;
    }
    public void setIdMod(int idMod) {
        this.idMod = idMod;
    }
    public String getNomModule() {
        return nomModule;
    }
    public void setNomModule(String nomModule) {
        this.nomModule = nomModule;
    }
}

